/*
 * ATTENTION: An "eval-source-map" devtool has been used.
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file with attached SourceMaps in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
(() => {
var exports = {};
exports.id = "pages/vending-machine";
exports.ids = ["pages/vending-machine"];
exports.modules = {

/***/ "./pages/vending-machine.js":
/*!**********************************!*\
  !*** ./pages/vending-machine.js ***!
  \**********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (/* binding */ VendingMachine)\n/* harmony export */ });\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ \"react/jsx-dev-runtime\");\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! next/head */ \"next/head\");\n/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_head__WEBPACK_IMPORTED_MODULE_1__);\n/* harmony import */ var bulma_css_bulma_css__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! bulma/css/bulma.css */ \"./node_modules/bulma/css/bulma.css\");\n/* harmony import */ var bulma_css_bulma_css__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(bulma_css_bulma_css__WEBPACK_IMPORTED_MODULE_2__);\n\n\n\n\nfunction VendingMachine() {\n    return /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"div\", {\n        children: [\n            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"head\", {\n                children: [\n                    /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"title\", {\n                        children: \"Vending Machine App\"\n                    }, void 0, false, {\n                        fileName: \"/root/vending_tutorial/vending-machine-app/pages/vending-machine.js\",\n                        lineNumber: 11,\n                        columnNumber: 5\n                    }, this),\n                    /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"meta\", {\n                        name: \"description\",\n                        content: \"A blockchain vending machine app\"\n                    }, void 0, false, {\n                        fileName: \"/root/vending_tutorial/vending-machine-app/pages/vending-machine.js\",\n                        lineNumber: 12,\n                        columnNumber: 5\n                    }, this)\n                ]\n            }, void 0, true, {\n                fileName: \"/root/vending_tutorial/vending-machine-app/pages/vending-machine.js\",\n                lineNumber: 10,\n                columnNumber: 4\n            }, this),\n            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"nav\", {\n                className: \"navbar\",\n                children: /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"div\", {\n                    className: \"container\",\n                    children: [\n                        /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"div\", {\n                            className: \"navbar-brand\",\n                            children: /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"h1\", {\n                                children: \"Vending Machine App\"\n                            }, void 0, false, {\n                                fileName: \"/root/vending_tutorial/vending-machine-app/pages/vending-machine.js\",\n                                lineNumber: 17,\n                                columnNumber: 7\n                            }, this)\n                        }, void 0, false, {\n                            fileName: \"/root/vending_tutorial/vending-machine-app/pages/vending-machine.js\",\n                            lineNumber: 16,\n                            columnNumber: 6\n                        }, this),\n                        /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"div\", {\n                            className: \"navbar-end\",\n                            children: /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"button\", {\n                                className: \"button is-primary\",\n                                children: \"Connect Wallet\"\n                            }, void 0, false, {\n                                fileName: \"/root/vending_tutorial/vending-machine-app/pages/vending-machine.js\",\n                                lineNumber: 20,\n                                columnNumber: 7\n                            }, this)\n                        }, void 0, false, {\n                            fileName: \"/root/vending_tutorial/vending-machine-app/pages/vending-machine.js\",\n                            lineNumber: 19,\n                            columnNumber: 6\n                        }, this)\n                    ]\n                }, void 0, true, {\n                    fileName: \"/root/vending_tutorial/vending-machine-app/pages/vending-machine.js\",\n                    lineNumber: 15,\n                    columnNumber: 5\n                }, this)\n            }, void 0, false, {\n                fileName: \"/root/vending_tutorial/vending-machine-app/pages/vending-machine.js\",\n                lineNumber: 14,\n                columnNumber: 4\n            }, this)\n        ]\n    }, void 0, true, {\n        fileName: \"/root/vending_tutorial/vending-machine-app/pages/vending-machine.js\",\n        lineNumber: 9,\n        columnNumber: 3\n    }, this);\n};\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9wYWdlcy92ZW5kaW5nLW1hY2hpbmUuanMuanMiLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7OztBQUNBO0FBQTRCO0FBQ0E7QUFDNEI7QUFHekMsU0FBU0UsY0FBYyxHQUFHO0lBQ3hDLHFCQUNDLDhEQUFDQyxLQUFHOzswQkFDSCw4REFBQ0MsTUFBSTs7a0NBQ0osOERBQUNDLE9BQUs7a0NBQUMscUJBQW1COzs7Ozs0QkFBUTtrQ0FDbEMsOERBQUNDLE1BQUk7d0JBQUNDLElBQUksRUFBQyxhQUFhO3dCQUFDQyxPQUFPLEVBQUMsa0NBQWtDOzs7Ozs0QkFBRzs7Ozs7O29CQUNoRTswQkFDUCw4REFBQ0MsS0FBRztnQkFBQ0MsU0FBUyxFQUFDLFFBQVE7MEJBQ3RCLDRFQUFDUCxLQUFHO29CQUFDTyxTQUFTLEVBQUMsV0FBVzs7c0NBQ3pCLDhEQUFDUCxLQUFHOzRCQUFDTyxTQUFTLEVBQUMsY0FBYztzQ0FDNUIsNEVBQUNDLElBQUU7MENBQUMscUJBQW1COzs7OztvQ0FBSzs7Ozs7Z0NBQ3ZCO3NDQUNOLDhEQUFDUixLQUFHOzRCQUFDTyxTQUFTLEVBQUMsWUFBWTtzQ0FDMUIsNEVBQUNFLFFBQU07Z0NBQUNGLFNBQVMsRUFBQyxtQkFBbUI7MENBQUMsZ0JBQWM7Ozs7O29DQUFTOzs7OztnQ0FDeEQ7Ozs7Ozt3QkFDRDs7Ozs7b0JBQ0Q7Ozs7OztZQUNELENBQ047Q0FDRCIsInNvdXJjZXMiOlsid2VicGFjazovL3ZlbmRpbmctbWFjaGluZS1hcHAvLi9wYWdlcy92ZW5kaW5nLW1hY2hpbmUuanM/MDY2YyJdLCJzb3VyY2VzQ29udGVudCI6WyJcbmltcG9ydCBIZWFkIGZyb20gJ25leHQvaGVhZCdcbmltcG9ydCAnYnVsbWEvY3NzL2J1bG1hLmNzcydcbmltcG9ydCBzdHlsZXMgZnJvbSAnLi4vc3R5bGVzL1ZlbmRpbmdNYWNoaW5lLm1vZHVsZS5jc3MnXG5cblxuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gVmVuZGluZ01hY2hpbmUoKSB7XG5cdHJldHVybiAoXG5cdFx0PGRpdj5cblx0XHRcdDxoZWFkPlxuXHRcdFx0XHQ8dGl0bGU+VmVuZGluZyBNYWNoaW5lIEFwcDwvdGl0bGU+XG5cdFx0XHRcdDxtZXRhIG5hbWU9XCJkZXNjcmlwdGlvblwiIGNvbnRlbnQ9XCJBIGJsb2NrY2hhaW4gdmVuZGluZyBtYWNoaW5lIGFwcFwiIC8+XG5cdFx0XHQ8L2hlYWQ+XG5cdFx0XHQ8bmF2IGNsYXNzTmFtZT1cIm5hdmJhclwiPlxuXHRcdFx0XHQ8ZGl2IGNsYXNzTmFtZT1cImNvbnRhaW5lclwiPlxuXHRcdFx0XHRcdDxkaXYgY2xhc3NOYW1lPVwibmF2YmFyLWJyYW5kXCI+XG5cdFx0XHRcdFx0XHQ8aDE+VmVuZGluZyBNYWNoaW5lIEFwcDwvaDE+XG5cdFx0XHRcdFx0PC9kaXY+XG5cdFx0XHRcdFx0PGRpdiBjbGFzc05hbWU9XCJuYXZiYXItZW5kXCI+XG5cdFx0XHRcdFx0XHQ8YnV0dG9uIGNsYXNzTmFtZT1cImJ1dHRvbiBpcy1wcmltYXJ5XCI+Q29ubmVjdCBXYWxsZXQ8L2J1dHRvbj5cblx0XHRcdFx0XHQ8L2Rpdj5cblx0XHRcdFx0PC9kaXY+XG5cdFx0XHQ8L25hdj5cblx0XHQ8L2Rpdj5cblx0KVxufVxuIl0sIm5hbWVzIjpbIkhlYWQiLCJzdHlsZXMiLCJWZW5kaW5nTWFjaGluZSIsImRpdiIsImhlYWQiLCJ0aXRsZSIsIm1ldGEiLCJuYW1lIiwiY29udGVudCIsIm5hdiIsImNsYXNzTmFtZSIsImgxIiwiYnV0dG9uIl0sInNvdXJjZVJvb3QiOiIifQ==\n//# sourceURL=webpack-internal:///./pages/vending-machine.js\n");

/***/ }),

/***/ "./node_modules/bulma/css/bulma.css":
/*!******************************************!*\
  !*** ./node_modules/bulma/css/bulma.css ***!
  \******************************************/
/***/ (() => {



/***/ }),

/***/ "next/head":
/*!****************************!*\
  !*** external "next/head" ***!
  \****************************/
/***/ ((module) => {

"use strict";
module.exports = require("next/head");

/***/ }),

/***/ "react/jsx-dev-runtime":
/*!****************************************!*\
  !*** external "react/jsx-dev-runtime" ***!
  \****************************************/
/***/ ((module) => {

"use strict";
module.exports = require("react/jsx-dev-runtime");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__("./pages/vending-machine.js"));
module.exports = __webpack_exports__;

})();