
import Head from 'next/head'
import 'bulma/css/bulma.css'
import styles from '../styles/VendingMachine.module.css'


export default function VendingMachine() {
	return (
		<div>
			<head>
				<title>Vending Machine App</title>
				<meta name="description" content="A blockchain vending machine app" />
			</head>
			<nav className="navbar">
				<div className="container">
					<div className="navbar-brand">
						<h1>Vending Machine App</h1>
					</div>
					<div className="navbar-end">
						<button className="button is-primary">Connect Wallet</button>
					</div>
				</div>
			</nav>
		</div>
	)
}
